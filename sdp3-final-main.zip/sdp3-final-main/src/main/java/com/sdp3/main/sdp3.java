package com.sdp3.main;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication

public class sdp3 {

	public static void main(String[] args) {
		
		SpringApplication.run(sdp3.class, args);
		
	}
		

}
